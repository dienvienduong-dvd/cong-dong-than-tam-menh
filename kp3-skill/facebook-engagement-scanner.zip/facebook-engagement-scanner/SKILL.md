---
name: facebook-engagement-scanner
description: >
  Quet danh sach nguoi tuong tac (like, comment, reaction) tren bat ky profile hay
  bai post Facebook nao va xuat ra bang uu tien de tu van ban hang AI Agents CC.
  Dung skill nay khi Tu muon: "quet tuong tac Facebook", "xem ai like bai gan day",
  "tim khach am tren Facebook", "scan engagement", "lay danh sach tuong tac", hoac
  khi paste bat ky link facebook.com nao vao. Skill nay dung Claude in Chrome de
  tu dong hover icon reactions, doc comment, va tong hop ket qua — khong can Tu tu
  copy tay. Profile mac dinh neu khong co link: facebook.com/tuchinguyen.cm.
  LUON dung skill nay truoc khi chay tu-van-ban-hang neu Tu chua co danh sach cu the.
---

# Skill: Facebook Engagement Scanner

Tự động quét người tương tác trên các bài post Facebook của Từ Chí Nguyện, chấm điểm mức độ "ấm", và xuất bảng ưu tiên tư vấn — sẵn sàng kết hợp với skill `tu-van-ban-hang`.

---

## Yêu cầu

- **Claude in Chrome** đang kết nối (Browser extension đã cài, đang mở Chrome)
- Đang đăng nhập Facebook tài khoản của Tu

---

## Quy trình thực hiện

### Bước 1 — Kết nối browser

```
Dùng list_connected_browsers → select_browser → xác nhận kết nối
```

### Bước 2 — Điều hướng đến profile Facebook

Navigate đến profile được chỉ định (mặc định: `facebook.com/tuchinguyen.cm`).
Đóng mọi popup/notification đang che nội dung.

### Bước 3 — Scroll và tìm bài post

- Scroll từ trên xuống, tìm các bài post có **reactions > 0**
- Ưu tiên bài có **nội dung liên quan AI / kinh doanh online / khóa học** — đây là signal mạnh nhất
- Mục tiêu: quét **5-10 bài gần nhất** hoặc theo số lượng Tu yêu cầu

### Bước 4 — Lấy tên + link profile người tương tác

Với mỗi bài post có reactions:

**Cách lấy tên — hover icon reaction:**
```
computer(hover, tọa độ icon ❤️👍😆 góc phải bài post)
→ wait 2 giây
→ screenshot → đọc tooltip (hiện tên 3-5 người đầu)
```

Với bài có **nhiều reactions hơn tooltip hiển thị** → click vào timestamp bài post → mở post riêng → hover reactions để thấy đầy đủ hơn.

**Cách lấy tên — đọc comment:**
```
Scroll phần comment của bài post
→ Ghi tên người comment + nội dung comment (tín hiệu quan trọng)
```

**Cách lấy link profile — BẮT BUỘC làm với mỗi người:**
```
Sau khi có tên từ tooltip/comment:
→ Click vào tên/avatar của người đó (mở profile hoặc mini card popup)
→ Đọc URL trên thanh địa chỉ hoặc hover link trong mini card
→ Ghi lại đúng link: facebook.com/[username] hoặc facebook.com/profile.php?id=XXXXX
→ Nhấn Back (hoặc đóng mini card) để quay lại bài post gốc
→ Lặp lại cho người tiếp theo
```

Lý do bắt buộc lấy link: tên Facebook trùng nhau rất nhiều, link profile là định danh duy nhất để skill `tu-van-ban-hang` dùng trực tiếp mà không cần tìm lại.

### Bước 5 — Chấm điểm mức độ ấm

Áp dụng thang điểm sau cho từng người:

| Hành động | Điểm | Ghi chú |
|-----------|------|---------|
| Comment có nội dung | 🔥🔥🔥 | Cao nhất — chủ động tương tác |
| Like/React nhiều bài (2+) | 🔥🔥🔥 | Theo dõi liên tục |
| React ❤️ hoặc 😮 | 🔥🔥 | Cảm xúc mạnh hơn Like thường |
| Like 1 bài AI/kinh doanh | 🔥🔥 | Topic phù hợp |
| Like 1 bài bất kỳ | 🔥 | Có tương tác, cần xác nhận thêm |

### Bước 6 — Xuất kết quả

Xuất bảng theo format sau:

```
## 📋 Kết quả quét engagement — [ngày quét]
**Profile quét:** facebook.com/[profile]
**Số bài quét:** X bài | **Tổng người tương tác unique:** Y người

| # | Tên | Link Facebook | Loại tương tác | Bài post liên quan | Mức độ ấm |
|---|-----|--------------|---------------|-------------------|-----------|
| 1 | Nguyễn Văn A | facebook.com/nguyen.van.a | Comment: "hay quá" | Demo AI agent | 🔥🔥🔥 |
| 2 | Trần Thị B | facebook.com/profile.php?id=123 | Like (2 bài) | Landing page + LIVE | 🔥🔥🔥 |
...

**Top 3 nên tiếp cận trước:**
1. [Tên] (facebook.com/...) — lý do ngắn
2. [Tên] (facebook.com/...) — lý do ngắn
3. [Tên] (facebook.com/...) — lý do ngắn
```

---

## Sau khi xuất kết quả

Hỏi Tu:
> "Anh muốn build kịch bản tư vấn cho ai trong danh sách này? (paste tên hoặc nói 'tất cả top 3')"

Nếu Tu chỉ định tên → **tự động kích hoạt skill `tu-van-ban-hang`** cho từng người đó.

---

## Giới hạn kỹ thuật cần biết

- **Tooltip hover** chỉ hiện ~5 tên đầu — với bài nhiều reactions cần vào post riêng
- **Facebook có thể chặn** nếu quét quá nhanh liên tục — nên quét 5-10 bài/lần, không quét toàn bộ 1 lúc
- **Profile private** sẽ không hiện tên — bỏ qua, không cần cố
- **Tài khoản chính chủ** mới thấy đầy đủ reactions — skill chỉ hoạt động khi đăng nhập đúng tài khoản Tu

---

## Tham số tùy chỉnh

Tu có thể chỉ định khi gọi skill:

| Tham số | Mặc định | Ví dụ |
|---------|----------|-------|
| Profile Facebook | tuchinguyen.cm (mặc định nếu không paste link) | "quét facebook.com/abc" |
| Số bài quét | 5 bài gần nhất | "quét 10 bài" |
| Lọc theo chủ đề | Tất cả | "chỉ lấy bài về AI" |
| Ngưỡng reactions | Tất cả | "chỉ bài có 5+ reactions" |

---

## Kết hợp với skill khác

Sau khi quét xong, skill này **tự động gợi ý** kích hoạt:
- `tu-van-ban-hang` — build kịch bản cho từng người trong danh sách
