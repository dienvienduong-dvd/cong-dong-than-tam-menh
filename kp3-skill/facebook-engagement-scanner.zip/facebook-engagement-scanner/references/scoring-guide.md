# Scoring Guide — Chấm điểm mức độ ấm khách hàng

## Nguyên tắc chấm điểm

Mục tiêu không phải chấm ai "thích AI nhất" — mà chấm ai **có khả năng mua cao nhất**.
Tín hiệu mua hàng khác tín hiệu quan tâm thông thường.

---

## Bảng điểm chi tiết

### 🔥🔥🔥 Rất ấm — Tiếp cận ngay

| Tín hiệu | Lý do |
|----------|-------|
| Comment hỏi giá / chi tiết khóa | Đang cân nhắc mua |
| Comment tag người khác vào bài AI | Muốn chia sẻ, có network phù hợp |
| Like + Comment cùng 1 bài | Double engagement |
| Tương tác 2+ bài liên quan AI/kinh doanh | Theo dõi chủ đề |
| Reply comment của Tu | Đã có hội thoại, ấm nhất |

### 🔥🔥 Ấm — Tiếp cận trong tuần

| Tín hiệu | Lý do |
|----------|-------|
| Like bài về AI / kinh doanh online | Topic match |
| React ❤️ hoặc 😮 (không phải 👍 thường) | Cảm xúc mạnh hơn |
| Like 1 bài nhưng profile liên quan (marketer, kinh doanh, freelancer) | Audience fit cao |
| Comment chung chung ("hay quá", "👍") | Có chú ý, chưa chủ động |

### 🔥 Cần xác nhận thêm — Tiếp cận sau

| Tín hiệu | Lý do |
|----------|-------|
| Like bài không liên quan AI | Có thể like vì quen biết |
| Profile không rõ ngành nghề | Chưa đủ thông tin |
| Tương tác 1 lần duy nhất, bài lâu | Cold dần |

---

## Bonus signal khi xem profile

Khi hover/click vào profile người tương tác, tìm thêm:

**Tăng điểm:**
- Nghề: marketer, kinh doanh, freelancer, giáo viên, coach, content creator
- Bio: đang bán hàng online, muốn tăng thu nhập, làm remote
- Số followers: 500-10K (đủ audience để apply AI agents)
- Bài viết gần đây: về AI, kinh doanh, học kỹ năng mới

**Giảm điểm:**
- Tài khoản ảo / ít hoạt động (< 5 bài/năm)
- Profile khóa hoàn toàn
- Nghề không liên quan (học sinh cấp 2, hưu trí xa lĩnh vực kinh doanh)

---

## Ví dụ chấm điểm thực tế

| Tên | Tín hiệu | Điểm |
|-----|----------|------|
| Thiên Tân | Like 2 bài AI khác nhau | 🔥🔥🔥 |
| Trần Minh Đoàn | Comment reply trực tiếp | 🔥🔥🔥 |
| Cẩm Tú | Like bài landing page AI, profile content creator | 🔥🔥 |
| Huỳnh Quốc Vân | Like bài LIVE, 4.9K followers | 🔥🔥🔥 |
| Nguyễn X | Like bài ảnh cá nhân (không liên quan AI) | 🔥 |
